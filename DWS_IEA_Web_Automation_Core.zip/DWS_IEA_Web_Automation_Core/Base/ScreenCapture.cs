﻿// <copyright file="ScreenCapture.cs" company="wearejust">
// Copyright © 2020 Just Group plc. All rights reserved.</copyright>

using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace DWS_IEA_Web_Automation_Core.Base
{
    public class ScreenCapture
    {
        /// <summary>
        ///     Creates an Image object containing a screen shot of the entire desktop
        /// </summary>
        /// <returns></returns>
        public static Image CaptureScreen()
        {
            return CaptureWindow(User32.GetDesktopWindow());
        }

        /// <summary>
        ///     Creates an Image object containing a screen shot of a specific window
        /// </summary>
        /// <param name="handle">The handle to the window. (In windows forms, this is obtained by the Handle property)</param>
        /// <returns></returns>
        public static Image CaptureWindow(IntPtr handle)
        {
            // get te hDC of the target window
            var hdcSrc = User32.GetWindowDC(handle);

            // get the size
            var windowRect = new User32.Rect();
            User32.GetWindowRect(handle, ref windowRect);
            var width = windowRect.right - windowRect.left;
            var height = windowRect.bottom - windowRect.top;

            // create a device context we can copy to
            var hdcDest = Gdi32.CreateCompatibleDC(hdcSrc);

            // create a bitmap we can copy it to,
            // using GetDeviceCaps to get the width/height
            var hBitmap = Gdi32.CreateCompatibleBitmap(hdcSrc, width, height);

            // select the bitmap object
            var hOld = Gdi32.SelectObject(hdcDest, hBitmap);

            Gdi32.BitBlt(hdcDest, 0, 0, width, height, hdcSrc, 0, 0, Gdi32.SrcCopy);

            // restore selection
            Gdi32.SelectObject(hdcDest, hOld);

            // clean up 
            Gdi32.DeleteDC(hdcDest);
            User32.ReleaseDC(handle, hdcSrc);

            // get a .NET image object for it
            Image img = Image.FromHbitmap(hBitmap);

            // free up the Bitmap object
            Gdi32.DeleteObject(hBitmap);
            return img;
        }

        /// <summary>
        ///     Captures a screen shot of the entire desktop, and saves it to a file
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="format"></param>
        public static void CaptureScreenToFile(string filename, ImageFormat format)
        {
            try
            {
                var img = CaptureScreen();
                img.Save(filename, format);
            }
            catch (Exception e)
            {
                Debug.WriteLine("Saving image exception:: " + e.Message);
            }
        }

        /// <summary>
        ///     Captures a screen shot of a specific window, and saves it to a file
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="filename"></param>
        /// <param name="format"></param>
        public void CaptureWindowToFile(IntPtr handle, string filename, ImageFormat format)
        {
            var img = CaptureWindow(handle);
            img.Save(filename, format);
        }

        public static Tuple<bool, string> TakeScreenShot(string directoryPath, string fName = null)
        {
            if (directoryPath == null)
            {
                throw new ArgumentNullException(nameof(directoryPath));
            }

            if (string.IsNullOrEmpty(fName))
            {
                // ReSharper disable once StringLiteralTypo
                fName = DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg";
            }

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            fName = Regex.Replace(fName, @"[;,""""'\t\r \\ \n\-]?", "");
            if (fName.Length > 70)
            {
                fName = fName.Substring(fName.Length / 3);
            }

            Tuple<bool, string> result = null;
            try
            {
                var screenShotFileName = directoryPath + fName;
                CaptureScreenToFile(screenShotFileName, ImageFormat.Jpeg);

                result = new Tuple<bool, string>(File.Exists(screenShotFileName), screenShotFileName);

                if (result.Item1 == false)
                {
                    try
                    {
                        screenShotFileName = directoryPath + fName;
                        var img = ScreenCapture.CaptureScreen();
                        img.Save(screenShotFileName, ImageFormat.Jpeg);
                    }
                    catch (Exception)
                    {
                        /* */
                    }

                    result = new Tuple<bool, string>(File.Exists(screenShotFileName), screenShotFileName);
                }
            }
            catch (Exception)
            {
                /* */
            }

            return result;
        }

        /// <summary>
        ///     Helper class containing Gdi32 API functions
        /// </summary>
        private static class Gdi32
        {
            public const int SrcCopy = 0x00CC0020; // BitBlt dwRop parameter

            [DllImport("gdi32.dll")]
            public static extern bool BitBlt(
                IntPtr hObject,
                int nXDest,
                int nYDest,
                int nWidth,
                int nHeight,
                IntPtr hObjectSource,
                int nXSrc,
                int nYSrc,
                int dwRop);

            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleBitmap(
                IntPtr hDc,
                int nWidth,
                int nHeight);

            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleDC(IntPtr hDc);

            [DllImport("gdi32.dll")]
            public static extern bool DeleteDC(IntPtr hDc);

            [DllImport("gdi32.dll")]
            public static extern bool DeleteObject(IntPtr hObject);

            [DllImport("gdi32.dll")]
            public static extern IntPtr SelectObject(IntPtr hDc, IntPtr hObject);
        }

        /// <summary>
        ///     Helper class containing User32 API functions
        /// </summary>
        private static class User32
        {
            [DllImport("user32.dll")]
            public static extern IntPtr GetDesktopWindow();

            [DllImport("user32.dll")]
            public static extern IntPtr GetWindowDC(IntPtr hWnd);

            [DllImport("user32.dll")]
            public static extern IntPtr GetWindowRect(IntPtr hWnd, ref Rect rect);

            [DllImport("user32.dll")]
            public static extern IntPtr ReleaseDC(IntPtr hWnd, IntPtr hDc);

            [StructLayout(LayoutKind.Sequential)]
            public readonly struct Rect
            {
                public readonly int left;
                public readonly int top;
                public readonly int right;
                public readonly int bottom;
            }
        }
    }
}
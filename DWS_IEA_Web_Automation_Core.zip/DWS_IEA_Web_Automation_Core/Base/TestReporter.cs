﻿// <copyright file="TestReporter.cs" company="wearejust">
// Copyright © 2020 Just Group plc. All rights reserved.</copyright>


using System;
using System.IO;
using System.Threading;

using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;

using TechTalk.SpecFlow;

namespace DWS_IEA_Web_Automation_Core.Base
{
  
    public class TestReporter
    {
        /// <summary>
        ///     Access reporting property structure from another class
        /// </summary>
        private ReportConfig bddReports;

        public TestReporter(ReportConfig config)
        {
            bddReports = config;
            InitReporting();
        }

        private  static ExtentHtmlReporter ExtentHtmlReporter { set; get; }

        private static ExtentReports ExtentReport { set; get; }

        private static ExtentTest FeatureTest { set; get; }

        private static string ReportDirectoryName { set; get; }

        private static ExtentTest ScenarioTest { set; get; }

        /// <summary>
        ///     Close the reporter
        /// </summary>
        public void CloseReporting()
        {
            

            ExtentReport.Flush();

            ExtentReport.ResetSession();

            var fName = ReportDirectoryName + "index.html";

            var loopCount = 0;
            while (!File.Exists(fName) && loopCount < 50)
            {
                try
                { Thread.Sleep(50);}

                catch (Exception){
                    /* */
                }

                loopCount++;
            }

            if (!File.Exists(fName))
            {
                return;
            }

            var contents = File.ReadAllText(fName);
            File.WriteAllText(this.bddReports.ReportFilePath, contents.Replace("index.html", ReportDirectoryName + this.bddReports.FileName));
            File.Delete(ReportDirectoryName + "index.html");


        }



        /// <summary>
        ///     Create the reporting Feature
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        public void CreateFeature(string name, string description)
        {
            FeatureTest = ExtentReport.CreateTest<Feature>(name, description);
        }

        /// <summary>
        ///     Create the reporting Scenario
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        public void CreateScenario(string name, string description)
        {
            ScenarioTest = FeatureTest.CreateNode<Scenario>(name, description);
        }

        /// <summary>
        ///     Assign status and screenshots  to test reporter
        /// </summary>
        /// <param name="reportScenario"></param>
        /// <param name="screenShotFilePath"></param>
        public void LogStatus(ScenarioContext reportScenario, string screenShotFilePath)
        {
            var stepNode = CreateStepNode(reportScenario.StepContext.StepInfo);

            stepNode = AssignTestStatus(reportScenario, stepNode);

            var relativePath = screenShotFilePath;
            if (!string.IsNullOrEmpty(screenShotFilePath))
            {
                int idx;
                if ((idx = screenShotFilePath.IndexOf("screenshots", StringComparison.InvariantCultureIgnoreCase)) != -1)
                {
                    relativePath = screenShotFilePath.Substring(idx);
                }
            }

            if (screenShotFilePath != null &&
                File.Exists(screenShotFilePath))
            {
                stepNode.AddScreenCaptureFromPath(relativePath);
            }

            stepNode.Log(
                Status.Info,
                "Step Details : <br> "
                + reportScenario.StepContext.StepInfo.Text + "<br>"
                + DateTime.UtcNow.ToString("hh:mm:ss.fff") + "<br />"
                + "<img align=left, width=960, height=540, src=\"" + relativePath
                + "\" ></img>"
            );
        }

        /// <summary>
        ///  Assign status and screenshots  to test reporter
        /// </summary>
        /// <param name="stepName"></param>
        /// <param name="status"></param>
        /// <param name="screenShotFilePath"></param>
        public void LogStatus(string stepName, bool status,  string screenShotFilePath)
        {
            var createdNode = ScenarioTest.CreateNode<Given>(stepName);
            switch (status)
            {
                case true:
                    createdNode = createdNode.Pass("Step Pass");
                    break;
                case false:
                    createdNode = createdNode.Fail("Step Fail");
                    break;

                default:
                    break;
            }
         

            var relativePath = screenShotFilePath;
            if (!string.IsNullOrEmpty(screenShotFilePath))
            {
                int idx;
                if ((idx = screenShotFilePath.IndexOf("screenshots", StringComparison.InvariantCultureIgnoreCase)) != -1)
                {
                    relativePath = screenShotFilePath.Substring(idx);
                }
            }

            if (screenShotFilePath != null &&
                File.Exists(screenShotFilePath))
            {
                createdNode.AddScreenCaptureFromPath(relativePath);
            }

            createdNode.Log(
                Status.Info,
                "Step Details : <br> "
                + stepName + "<br>"
                + DateTime.UtcNow.ToString("hh:mm:ss.fff") + "<br />"
                + "<img align=left, width=960, height=540, src=\"" + relativePath
                + "\" ></img>"
            );
        }


        /// <summary>
        ///     Create an instance of step Node for each Gherkin Step defined
        /// </summary>
        /// <param name="reportScenario"></param>
        /// <param name="stepNode"></param>
        /// <returns></returns>
        private ExtentTest AssignTestStatus(ScenarioContext reportScenario, ExtentTest stepNode)
        {
            switch (reportScenario.ScenarioExecutionStatus)
            {
                case ScenarioExecutionStatus.OK:
                    stepNode.Pass("Step Pass");
                    break;
                case ScenarioExecutionStatus.BindingError:
                    stepNode = stepNode.Fail("Binding Error :" + reportScenario.TestError.Message);
                    break;
                case ScenarioExecutionStatus.Skipped:
                    stepNode.Skip("Step Skipped");
                    break;
                case ScenarioExecutionStatus.StepDefinitionPending:
                    stepNode.Warning("Step Pending Implementation");
                    break;
                case ScenarioExecutionStatus.TestError:
                    stepNode.Fail("Test Error :" + reportScenario.TestError.Message);
                    break;
                case ScenarioExecutionStatus.UndefinedStep:
                    stepNode.Warning("Undefined Step with " + reportScenario.ScenarioInfo.Arguments + " arguments");
                    break;
            }

            return stepNode;
        }

        /// <summary>
        ///     Create an instance of step Node for each Gherkin Step defined
        /// </summary>
        /// <param name="stepInfo"></param>
        /// <returns></returns>
        private ExtentTest CreateStepNode(StepInfo stepInfo)
        {
            var stepType = stepInfo.StepInstance.StepDefinitionType.ToString();
            ExtentTest stepNode = null;

            switch (stepType)
            {
                case "Given":
                    stepNode = ScenarioTest.CreateNode<Given>(stepInfo.Text);
                    break;
                case "When":
                    stepNode = ScenarioTest.CreateNode<When>(stepInfo.Text);
                    break;
                case "Then":
                    stepNode = ScenarioTest.CreateNode<Then>(stepInfo.Text);
                    break;
                case "And":
                    stepNode = ScenarioTest.CreateNode<And>(stepInfo.Text);
                    break;
                case "But":
                    stepNode = ScenarioTest.CreateNode<But>(stepInfo.Text);
                    break;
            }

            return stepNode;
        }

        /// <summary>
        ///     Initialise all the necessary configuration for reporting
        /// </summary>
        private void InitReporting()
        {
            var fInfo = new FileInfo(bddReports.ReportFilePath);
            ReportDirectoryName = bddReports.ReportFilePath.Replace(fInfo.Name, "");

            bddReports.FileName = fInfo.Name;

            if (!Directory.Exists(ReportDirectoryName))
            {
                Directory.CreateDirectory(ReportDirectoryName);
            }

            ExtentHtmlReporter = new ExtentHtmlReporter(ReportDirectoryName);

            //initialize ExtentReports and attach the HtmlReporter
            ExtentReport = new ExtentReports();

            //To add system or environment info by using the setSystemInfo method.
            ExtentReport.AddSystemInfo("Domain Name", Environment.UserDomainName);
            ExtentReport.AddSystemInfo("OS  Platform", Environment.OSVersion.Platform.ToString());
            ExtentReport.AddSystemInfo("OS  Version", Environment.OSVersion.ToString());
            ExtentReport.AddSystemInfo("Machine Name", Environment.MachineName);
            ExtentReport.AddSystemInfo("User Name", Environment.UserName);

            //set BDD report Style
            ExtentReport.AnalysisStrategy = AnalysisStrategy.BDD;

            //configuration items to change the look and feel
            //add content, manage tests etc

            ExtentHtmlReporter.Config.DocumentTitle = bddReports.ReportTitle;
            ExtentHtmlReporter.Config.CSS = "css-string";
            ExtentHtmlReporter.Config.EnableTimeline = true;
            ExtentHtmlReporter.Config.Encoding = "utf-8";
            ExtentHtmlReporter.Config.JS = "js-string";
            ExtentHtmlReporter.Config.Theme = Theme.Dark;
            ExtentHtmlReporter.Config.ReportName = bddReports.ReportDocName.Replace(" ", "_") + fInfo.Name;

            ExtentHtmlReporter.Start();
            ExtentReport.AttachReporter(ExtentHtmlReporter);
        }

        public struct ReportConfig
        {
            public string ReportFilePath { set; get; }

            public string ReportTitle { set; get; }

            public string ReportDocName { set; get; }

            public string FeatureInfoTitle { set; get; }

            public string ScenarioInfoTitle { set; get; }

            public string FileName { set; get; }
        }
    }
}

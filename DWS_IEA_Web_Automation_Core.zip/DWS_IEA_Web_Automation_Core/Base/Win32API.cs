﻿
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;
using FlaUI.UIA3;
using System.Diagnostics;
using System.Threading;
using System.Linq;
using WindowsInput.Native;
using WindowsInput;
using System;

namespace DWS_IEA_Web_Automation_Core.Base
{
    // https://www.csharpcodi.com/vs2/?source=4474/FlaUI/src/FlaUI.Core.UITests/CalculatorTests.cs


    /// <summary>
    /// Static class that lists all windows
    /// </summary>
    public static class Win32API
    {

    private static readonly UIA3Automation uiAuthomation = new UIA3Automation();
    private static string BrowserProcessName;
    private static readonly InputSimulator simulator = new InputSimulator();
    private static FlaUI.Core.AutomationElements.AutomationElement ieBrowSer;
    private static FlaUI.Core.AutomationElements.AutomationElement cachedDesktop;
    private static bool hasNotMaximised;

    public static string currentUrl;


        /// <summary>
        /// /runs a process as a user
        /// </summary>
        /// <param name="browserProcess"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        public static void RunBrowserAsUser(string browserProcess, string browserDir, string username, string password)
        {
            BrowserProcessName = browserProcess;

            if (ieBrowSer == null)
            {
                
                Process.Start("explorer.exe", "/select," + "\"" + browserDir + browserProcess + "\"");

                int count = 0;
                var ieFileView = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName(BrowserProcessName));
                while (ieFileView == null && count < 10)
                {
                    Thread.Sleep(500);
                    ieFileView = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName(BrowserProcessName));
                    count++;
                }

                if (ieFileView != null)
                {

                    Keyboard.Press(VirtualKeyShort.SHIFT);
                    ieFileView.SetForeground();
                    ieFileView.RightClick();
                    Thread.Sleep(500);

                    count = 0;
                    var differentUserDialog = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName("Run as a different user"));
                    while (differentUserDialog == null && count < 10)
                    {
                        Thread.Sleep(500);
                        differentUserDialog = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName("Run as a different user"));
                        count++;
                    }
                    if (differentUserDialog != null)
                    {
                        differentUserDialog.Click();

                        Keyboard.Release(VirtualKeyShort.SHIFT);
                        Thread.Sleep(1000);

                        count = 0;
                        var winSecurityDialog = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName("Windows Security"));
                        while (winSecurityDialog == null && count < 10)
                        {
                            Thread.Sleep(500);
                            winSecurityDialog = uiAuthomation.GetDesktop().FindFirstDescendant(item => item.ByName("Windows Security"));
                            count++;
                        }

                        if (winSecurityDialog != null)
                        {
                            Thread.Sleep(100);
                            var userText = winSecurityDialog.FindAllDescendants(item => item.ByName("Username"))[0];
                            userText.Focus();
                            lock (simulator)
                            {
                                simulator.Keyboard.TextEntry(username);
                                Wait.UntilInputIsProcessed();
                                Thread.Sleep(100);
                                simulator.Keyboard.KeyPress(VirtualKeyCode.TAB);
                                Thread.Sleep(100);


                                var passText = winSecurityDialog.FindAllDescendants(item => item.ByName("Password"))[0];
                                passText.Click();


                                simulator.Keyboard.TextEntry(password);
                                Wait.UntilInputIsProcessed();
                                Thread.Sleep(1200);
                            }

                            var okButton = winSecurityDialog.FindAllDescendants(item => item.ByName("OK"));

                            count = 0;
                            while (okButton != null && okButton.Count() > 0 && count < 7)
                            {
                                okButton[0].Focus();
                                okButton[0].Click();

                                okButton = winSecurityDialog.FindAllDescendants(item => item.ByName("OK"));
                                Thread.Sleep(500);
                                count++;
                            }

                            if (okButton == null || okButton.Count() == 0)
                            {
                                cachedDesktop = uiAuthomation.GetDesktop();

                                CloseIEFolder();
                            }

                            SetCurrentBrowser();
                        }
                    }
                }
            }

        }


        /// <summary>
        ///  Gets the current browser
        /// </summary>
        /// <param name="waitTimeInSecs"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement GetCurrentBrowser(int waitTimeInSecs = 5)
        {
            try
            {
                SetCurrentBrowser(waitTimeInSecs);
            }catch(Exception E)
            { var A =E.Message; }

            return ieBrowSer;

        }



        /// <summary>
        /// Checks if the browser exists
        /// </summary>
        public static bool DoesBrowserExist()
        {
            var process = Process.GetProcessesByName("iexplore").Where(x => x.MainWindowTitle.Contains(" - Internet Explorer"));

            return process.Any();
        }


        /// <summary>
        /// kills all ie browsers 
        /// </summary>
        public static void CloseBrowser()
        {
            var process = Process.GetProcessesByName("iexplore").Where(x => x.MainWindowTitle.Contains(" - Internet Explorer"));

            foreach (var item in process)
            {
                item.Kill();
            }
        }


        /// <summary>
        /// Sets the current browser
        /// </summary>
        /// <param name="waitTimeInSecs"></param>
        private static void SetCurrentBrowser(int waitTimeInSecs = 5)
        {
            var process = Process.GetProcessesByName("iexplore").Where(x => x.MainWindowTitle.Contains(" - Internet Explorer"));
            int count = 0;
            while (!process.Any() && count < waitTimeInSecs)
            {
                Thread.Sleep(1000);
                process = Process.GetProcessesByName("iexplore").Where(x => x.MainWindowTitle.Contains(" - Internet Explorer"));
                count++;
            }

            if (process.Any())
            {
                var browserPointer = uiAuthomation.GetDesktop().FindAllChildren(item => item.ByName(process.ElementAt(0).MainWindowTitle));

                count = 0;
                while (browserPointer.Count() <= 0 && count < 100)
                {
                    Thread.Sleep(20);
                    process = Process.GetProcessesByName("iexplore").Where(x => x.MainWindowTitle.Contains(" - Internet Explorer"));
                    browserPointer = uiAuthomation.GetDesktop().FindAllChildren(item => item.ByName(process.ElementAt(0).MainWindowTitle));
                    count++;
                }

                if (browserPointer.Count() == 1)
                {
                    ieBrowSer = browserPointer.ElementAt(0);
                    try
                    {
                        ieBrowSer.Focus();
                    }
                    catch (Exception) { }

                }
            }
         }
            

        /// <summary>
        /// click back on the current browser
        /// </summary>
        public static void BackBrowser()
        {
            try
            {
               
                simulator.Keyboard.KeyPress(VirtualKeyCode.DOWN);
                simulator.Keyboard.KeyPress(VirtualKeyCode.F11);
                WaitForBrowserToLoad();

                simulator.Keyboard.KeyPress(VirtualKeyCode.BROWSER_BACK);
                simulator.Keyboard.KeyPress(VirtualKeyCode.F11);

                WaitForBrowserToLoad();
                    
            }
            catch (Exception) { }
         
        }


        /// <summary>
        /// click forward on the current browser
        /// </summary>
        public static void ForwardBrowser()
        {
            try
            {
                ieBrowSer = GetCurrentBrowser();
                ieBrowSer.Focus();
                Keyboard.Press(VirtualKeyShort.ALT);
                Keyboard.Press(VirtualKeyShort.RIGHT);

                Keyboard.Release(VirtualKeyShort.ALT);
                Keyboard.Release(VirtualKeyShort.RIGHT);
                Wait.UntilInputIsProcessed();
                WaitForBrowserToLoad();

            }
            catch (Exception) { }
            Thread.Sleep(500);

        }

        /// <summary>
        /// Closes IE launch folder
        /// </summary>
        private static void CloseIEFolder()
        {
           
            foreach (var item in cachedDesktop.FindAllChildren(item => item.ByName("Internet Explorer")))
            {
                try
                {
                    if (item.ControlType == FlaUI.Core.Definitions.ControlType.Window)
                    {
                        item.SetForeground();

                        Keyboard.Press(VirtualKeyShort.ALT);
                        Keyboard.Press(VirtualKeyShort.F4);

                        Keyboard.Release(VirtualKeyShort.ALT);
                        Keyboard.Release(VirtualKeyShort.F4);

     
                    }
                }
                catch (Exception) { }
               
            }

           


        }


        /// <summary>
        /// waits for a browser to load
        /// </summary>
        public static void WaitForBrowserToLoad()
        {
      
            var busyIE = Process.GetProcessesByName("iexplore").Where(x => x.Responding == false).ToList();
            while (busyIE.Count > 0 )
            {
                busyIE = Process.GetProcessesByName("iexplore").Where(x => x.Responding == false).ToList();
                Thread.Sleep(500);
            }
           
            Thread.Sleep(1000);
           

        }


        /// <summary>
        ///Maximize browser
        /// </summary>
        public static void MaximiseBrowser()
        {

            var browser  = GetCurrentBrowser();
            
            if (!hasNotMaximised || browser.ActualHeight < 1000)
            {

                simulator.Keyboard.KeyPress(VirtualKeyCode.F11);
               
                hasNotMaximised = true;
            }


        }

        /// <summary>
        /// Navigate to a url
        /// </summary>
        /// <param name="url"></param>
        public static bool NavigateTo(string url)
        {
            bool navigateOk = false;
            if (FocusBrowserAddress())
            {

                lock (simulator)
                {
                  
                    simulator.Keyboard.KeyDown(VirtualKeyCode.CONTROL);
                    simulator.Keyboard.KeyPress(VirtualKeyCode.VK_A);
                    simulator.Keyboard.KeyUp(VirtualKeyCode.CONTROL);
                    simulator.Keyboard.KeyUp(VirtualKeyCode.BACK);
                    Thread.Sleep(300);
     
                    simulator.Keyboard.TextEntry(url);
                    for (int i = 0; i < 10; i++)
                    simulator.Keyboard.KeyUp(VirtualKeyCode.RIGHT);
                    
                    Wait.UntilInputIsProcessed();
                    Thread.Sleep(300);
                    
                    
                    simulator.Keyboard.KeyPress(VirtualKeyCode.RETURN);

                 
                    navigateOk = true;
                }

                WaitForBrowserToLoad();
                currentUrl = url;
            }

            FocusBrowserAddress();
            return navigateOk;
        }
      
      
        /// <summary>
        /// Gives the browser focus for url entry
        /// </summary>
        private static bool FocusBrowserAddress()
        {
            bool foundAddressBar = false;
            WaitForBrowserToLoad();

            SetCurrentBrowser();

            var addressBar = uiAuthomation.GetDesktop()
                    .FindAllDescendants(item => item.ByName("Address Bar"));


            int count = 0;
            while (addressBar.Count() <= 0 && count < 500)
            {
                Thread.Sleep(100);
                count++;

                addressBar = uiAuthomation.GetDesktop()
                .FindAllDescendants(item => item.ByName("Address Bar"));
            }

            if (addressBar.Any())
            {
                var addressBarChildren = addressBar.ElementAt(0).FindAllDescendants();
                FlaUI.Core.AutomationElements.AutomationElement address = null;
                foreach (var ele in addressBarChildren)
                {
                    try
                    {
                        if (ele.ClassName.Equals("Edit"))
                        {
                            address = ele;
                            foundAddressBar = true;
                            break;
                        }
                    }
                    catch (Exception) { }

                }
                address.SetForeground();
            }
            return foundAddressBar;
        }
        

      /// <summary>
      ///  finds ui elements by classname
      /// </summary>
      /// <param name="className"></param>
      /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsByClassName(string className)
        {
           return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByClassName(className));
        }



       

        /// <summary>
        ///  finds ui elements by automation id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsByAutomationID(string id)
        {
            return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByAutomationId(id));
        }

        /// <summary>
        ///  finds ui elements by name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsName(string name)
        {
            return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByName(name));
        }

        /// <summary>
        ///  finds ui elements by text
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsByText(string text)
        {
            return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByText(text));
        }

        /// <summary>
        ///  finds ui elements by value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsByValue(string value)
        {
            return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByValue(value));
        }

        /// <summary>
        ///  finds ui elements by control ttpe
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static FlaUI.Core.AutomationElements.AutomationElement[] FindElementsByControlType(FlaUI.Core.Definitions.ControlType type )
        {
            return uiAuthomation.GetDesktop().FindAllDescendants(item => item.ByControlType(type));
        }

    }
  }



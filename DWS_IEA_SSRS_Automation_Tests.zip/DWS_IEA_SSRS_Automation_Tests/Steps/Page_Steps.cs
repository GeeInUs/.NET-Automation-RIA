﻿using DWS_IEA_SSRS_Automation_Tests.Pages;
using TechTalk.SpecFlow;
using System.Linq;
using System.Threading;
using System.Collections.Generic;
using DWS_IEA_Web_Automation_Core.Base;
using System;
using System.IO;
using NUnit.Framework;
using FluentAssertions;
using System.Diagnostics;

namespace DWS_IEA_SSRS_Automation_Tests.Steps
{
    [Binding]
    public sealed class Page_Steps
    {


        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef
        private static readonly string  baseFolder = AppDomain.CurrentDomain.BaseDirectory + "SSRS_Automation_Results_" + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss") + "\\";
        private static readonly string ScreenShotDir = baseFolder + @"Reports\Screenshots\";
        public static readonly string ReportDir = baseFolder + @"Reports\";
        public static string TestStepName = "";
        private static string baseUrl;



        private static ScenarioContext _scenarioContext;
        private static  FeatureContext _featureContext;
        private static BrowsePage browsePage;
        private static ReportPage reportPage;
        public static TestReporter testReporter;
        private static FileWorker fw;

        private List<string> reportNames;
        private List<string> parameterNames;
        private List<string> rowCount;
        public static  Dictionary<string, string> reportPK ;



        public Page_Steps(ScenarioContext scenarioContext, FeatureContext featureContext)
        {

            _scenarioContext = scenarioContext;
            _featureContext = featureContext;

            SetUpScreenShotConfig();

            SetUpReportDir();

        }

        #region Class Hooks

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            fw = new FileWorker();
            reportPK = new Dictionary<string, string>();

            BaseWebPage.RunBeforeDriverLaunch();
            browsePage = new BrowsePage();
             fw = new FileWorker();

        }
        [BeforeStep]
        public void BeforeScenario()
        {
            TestStepName = ScenarioStepContext.Current.StepInfo.Text;
            testReporter.CreateScenario(_scenarioContext.ScenarioInfo.Title, "Scenario");
        }

        [AfterStep]
        public void AfterStep()
        {
            TakeScreenShot();
        }

        [AfterFeature]
        public static void AfterFeature()
        {
            testReporter.CloseReporting();
            testReporter = null;
           
        }


        [AfterTestRun]
        public static void AfterTestRun()
        {
            try
            {
                ReportPage.FlushReports();
                fw.DoWorkToCompareFiles(ReportDir + "\\SSRS",
                                         ReportDir + "\\PBRS");
            }
            catch (Exception) { }
            finally
            {
                Win32API.CloseBrowser();
                Process.Start("explorer.exe", "/open,\"" + ReportDir + "\"");

                browsePage.reportPage = null;
                browsePage = null;
                testReporter = null;
                fw = null;
            }
           
        }
        #endregion

        #region Helper Methods

        public static void TakeScreenShot()
        {
            if (Convert.ToBoolean(TestContext.Parameters["Browser.TakeScreenShot"]))
            {
                string filename = BaseWebPage.TakeScreenShot(ScreenShotDir, TestStepName + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg");
                testReporter.LogStatus(_scenarioContext, filename);
            }
        }



        public static string TakeScreenShot(string stepName, bool status)
        {
            string filename = "";
            if (Convert.ToBoolean(TestContext.Parameters["Browser.TakeScreenShot"]))
            {
                 filename = BaseWebPage.TakeScreenShot(ScreenShotDir, TestStepName + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg");
                testReporter.LogStatus(stepName,  status, filename);
            }
            return filename;
        }

        /// <summary>
        /// Where test screenshots will be stored
        /// </summary>
        private void SetUpScreenShotConfig()
        {
            if (! Directory.Exists(ScreenShotDir) )
            {
                Directory.CreateDirectory(ScreenShotDir);
            }
        }


        /// <summary>
        ///  wheere report  will be saved
        /// </summary>
        private void  SetUpReportDir()
        {
            if (testReporter != null)
                return;

            if (!Directory.Exists(ReportDir))
            {
                Directory.CreateDirectory(ReportDir);
            }

            TestReporter.ReportConfig config = new TestReporter.ReportConfig
            {
                ReportTitle = "SSRS Testing Results",
                FileName = _featureContext.FeatureInfo.Title + ".html",
                ScenarioInfoTitle = _scenarioContext.ScenarioInfo.Description,
                FeatureInfoTitle = _featureContext.FeatureInfo.Title,
                ReportDocName = "SSRS Report Testing",
                ReportFilePath = ReportDir + _featureContext.FeatureInfo.Title + ".html"
            };
            testReporter = new TestReporter(config);

            testReporter.CreateFeature(_featureContext.FeatureInfo.Title, "SSRS Feature");
        }
    
        #endregion

        #region Home page steps


        [Given(@"I login to ""(.*)"" with the username ""(.*)"" and password ""(.*)""")]
        [When(@"I login to ""(.*)"" with the username ""(.*)"" and password ""(.*)""")]
        [Then(@"I login to ""(.*)"" with the username ""(.*)"" and password ""(.*)""")]
        public void WhenILoginToWithTheUsernameAndPassword(string url, string userName, string password)
        {
            baseUrl = url;
            TestStepName = "1.Login_With_Authenticated_user__" + userName;

            Win32API.RunBrowserAsUser(TestContext.Parameters["Browser.Process"],
                                     TestContext.Parameters["Browser.Directory"],
                                      userName,
                                      password);

            int count = 0;
            while (Win32API.DoesBrowserExist() == false && count < 3)
            {
                Win32API.RunBrowserAsUser(TestContext.Parameters["Browser.Process"],
                                    TestContext.Parameters["Browser.Directory"],
                                     userName,
                                     password);
                Thread.Sleep(1000);
                count++;
            }
            Win32API.DoesBrowserExist().Should().BeTrue("Launched Browser ok");
         
            Win32API.WaitForBrowserToLoad();
            Win32API.MaximiseBrowser();
            Win32API.NavigateTo(url).Should().BeTrue("Navigatedto URL ok");
         

        }

        [Given(@"I drill to the web folder at ""(.*)""")]
        [When(@"I drill to the web folder at ""(.*)""")]
        [Then(@"I drill to the web folder at ""(.*)""")]
        public void GivenIDrillToFolderAt(string urlPart)
        {
            TestStepName = "2.Navigated_to_url_part ";
            Win32API.MaximiseBrowser();
            Win32API.NavigateTo(baseUrl + urlPart).Should().BeTrue("Navigated to URL ok");   
        }
        #endregion

        #region Browsing  page steps

        [When(@"I browse ""(.*)"" reports based on the following configuration")]
        [Given(@"I browse ""(.*)"" reports based on the following configuration")]
        [Then(@"I browse ""(.*)"" reports based on the following configuration")]
        public void WhenIBrowseReportsBasedOnTheFollowingConfiguration(string reportType, Table table)
        {
            var pk = table.Rows.AsEnumerable().Select(r => r["Comparer_Primary_Key"]).ToList();

            reportNames = table.Rows.AsEnumerable().Select(r => r["ReportName"]).ToList();
            rowCount = table.Rows.AsEnumerable().Select(r => r["ExpectedRowCount"]).ToList();
            parameterNames = table.Rows.AsEnumerable().Select(r => r["Parameters"]).ToList();
            for (int index = 0; index < reportNames.Count; index++)
            {
                lock (reportPK)
                {
                    var key = reportNames[index] + "_" + reportType;
                    if (!reportPK.ContainsKey(key))
                        reportPK.Add(key, pk[index]);
                }
            }

            reportPage = browsePage.AccessReports(reportType, reportNames, parameterNames, rowCount);

            
           
        }
        #endregion

        #region FileWorker steps

        [Given(@"I can compare reports and highlight differences")]
        [When(@"I can compare reports and highlight differences")]
        [Then(@"I can compare reports and highlight differences")]
        public void WhenILaunchEachReportFoundFromTheDrillDownFolderInTheReportPage()
        {
            
        }
        #endregion

    }
}

﻿using DWS_IEA_SSRS_Automation_Tests.Steps;
using DWS_IEA_Web_Automation_Core.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using TechTalk.SpecFlow;

namespace DWS_IEA_SSRS_Automation_Tests.Pages
{
    public class BrowsePage  
    {

        public  ReportPage reportPage;
       

        /// <summary>
        /// Class constructor
        /// </summary>
        public BrowsePage()
        {
            reportPage = new ReportPage();
        }

       
        /// <summary>
        ///link references to genuine reports 
        /// </summary>
        /// <param name="expectedReportNames"></param>
        /// <param name="reportParams"></param>
        /// <param name="reportParams"></param>
        /// <returns></returns>
        public ReportPage AccessReports(string reportType, List<string> expectedReportNames, List<string> reportParams, List<string> reportCount)
        {
            Win32API.WaitForBrowserToLoad();
            ReportPage.WaitForMaskToClear(120);

            var browser = Win32API.GetCurrentBrowser();
            int reportIdex = 2;

            //access reports
            for (int i = 0; i < expectedReportNames.Count; i++)
            {
                var expectedReportName = expectedReportNames[i];
                var expectedReportParam = reportParams[i];
                var actualReportName = expectedReportName;
                var expectedRowCount = reportCount[i];

                var hyperLink =  browser.FindAllDescendants(x => x.ByName(expectedReportName)).Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Hyperlink);
                var foundHyperLink = hyperLink.Any();


                Page_Steps.TakeScreenShot(reportIdex + ".Before_clicking_report", true);
                int count = 0;
                reportIdex++;
              
                try
                {
                    while (!foundHyperLink && count < 4)
                    {
                        browser = Win32API.GetCurrentBrowser();
                        hyperLink = browser.FindAllDescendants(x => x.ByName(expectedReportName));

                         Thread.Sleep(1000);
                        foundHyperLink = hyperLink.Any();
                        count++;

                    }
                    if (foundHyperLink) { hyperLink.ElementAt(0).Click();}
                    else actualReportName = "-";
                    Win32API.WaitForBrowserToLoad();
                    reportPage.LaunchReports(Win32API.currentUrl + "/" + expectedReportName,
                            reportType,
                            expectedReportName,
                            actualReportName,
                            expectedRowCount,
                            expectedReportParam.Split(new string[] { "," }, System.StringSplitOptions.RemoveEmptyEntries),
                            reportIdex);
                }
                catch (Exception) { }
                finally {

                    if (foundHyperLink)
                    {
                        Win32API.BackBrowser();
                    }

                }
            }

            return reportPage;
        }

        
        
        
    }
}

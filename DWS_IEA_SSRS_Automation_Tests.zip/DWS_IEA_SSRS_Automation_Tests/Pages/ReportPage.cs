﻿    using OpenQA.Selenium;
using System.Linq;
using System.Data;
using DWS_IEA_Web_Automation_Core.Base;
using System.Collections.Generic;
using System.Globalization;
using System;
using System.Threading;
using InputSimulatorStandard;
using DWS_IEA_SSRS_Automation_Tests.Steps;
using ClosedXML.Excel;
using InputSimulatorStandard.Native;
using System.IO;
using FlaUI.Core.Input;
using Spire.Xls;

namespace DWS_IEA_SSRS_Automation_Tests.Pages
{
   public class ReportPage 
    {
        public  static IWebDriver reportPageDriver;
        public static DataTable reportData;
        private static readonly InputSimulator simulator = new InputSimulator();
        private static readonly List<string> iMonth = new List<string> { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
        private static string genericErrors = "";


        // <summary>
        /// Class constructor
        /// </summary>
        public ReportPage()
        {  InitDT(); }

        /// <summary>
        /// creates report data
        /// </summary>
        private void InitDT()
        {

            if (reportData == null)
                reportData = new DataTable();
            else
                reportData.Rows.Clear();

            reportData.Columns.Add("Report Name", System.Type.GetType("System.String"));
            reportData.Columns.Add("Report Type", System.Type.GetType("System.String"));
            reportData.Columns.Add("Exist in Portal Dir", System.Type.GetType("System.Boolean"));
            reportData.Columns.Add("Link To Report", System.Type.GetType("System.String"));
            reportData.Columns.Add("Input Parameters Used", System.Type.GetType("System.String"));
            reportData.Columns.Add("Can View Reports", System.Type.GetType("System.Boolean"));
            reportData.Columns.Add("Expected Row Count", System.Type.GetType("System.Int32"));
            reportData.Columns.Add("Actual Row Count", System.Type.GetType("System.Int32"));
            reportData.Columns.Add("Diff in Row Count", System.Type.GetType("System.Int32"));
            reportData.Columns.Add("Is data in Table", System.Type.GetType("System.Boolean"));
            reportData.Columns.Add("Load Report (secs)", System.Type.GetType("System.Int32"));
            reportData.Columns.Add("Picture Evidence", System.Type.GetType("System.String"));
            reportData.Columns.Add("Download Evidence", System.Type.GetType("System.String"));
            reportData.Columns.Add("Data Match", System.Type.GetType("System.String"));
            reportData.Columns.Add("Auto Generated Comments", System.Type.GetType("System.String"));

        }





        /// <summary>
        ///  Launches a Report  based on parameters
        /// </summary>
        /// <param name="url"></param>
        /// <param name="expectedReportName"></param>
        /// <param name="actualReportName"></param>
        /// <param name="execptedRowCount"></param>
        /// <param name="reportArgs"></param>
        public void LaunchReports(string url, string reportType, string expectedReportName, string actualReportName, string execptedRowCount, string[] reportArgs, int reportIdex)
        {
            string actualRowCount = "0";
            bool loadedOk = false;
            DateTime startTime  = DateTime.Now;
            bool tableHasData  = false;
            Double endTimeInSecs = 0;
            string downloadedFileName = "";


            try
            {
                genericErrors = "";

                if (! Directory.Exists(Page_Steps.ReportDir + "\\" + reportType))
                    Directory.CreateDirectory(Page_Steps.ReportDir + "\\" + reportType);

                if (actualReportName != "-")
                {
                    var browser= WaitForMaskToClear(220);
                    Win32API.WaitForBrowserToLoad();
                    WaitForFrameToAppear();
                    loadedOk = InputParameters(reportArgs);

                    reportIdex++;
                    Page_Steps.TakeScreenShot(reportIdex + ".After_data_input", loadedOk);
                    startTime = DateTime.Now;
          
                    // click the view report
                    if (loadedOk)
                    {
                        if ( !(reportArgs.Length == 1 && reportArgs[0].ToLower().Trim() == "n/a") )
                        {
                            var viewReportButton = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByName("View Report"));
                            if (viewReportButton.Count() == 1)
                                viewReportButton.ElementAt(0).Click();
                        }
                        actualRowCount = GetReportCount();
                        tableHasData = browser.FindAllDescendants( x => x.ByName("Report table")).Any() || actualRowCount !=  "0";

                        endTimeInSecs = DateTime.Now.Subtract(startTime).TotalSeconds;
                        downloadedFileName= DownloadToExcel(reportType);
                    }
                }
                else
                {
                    loadedOk = false;
                    reportIdex = 0;
                }
            }
            catch (Exception e) { 
                loadedOk = false;
                genericErrors = e.Message;
                reportIdex = 0;
            }
            finally {
                 
                reportIdex++;
                GetPotentialErrors();
                var evidenceFName  = Page_Steps.TakeScreenShot(reportIdex + ".view_report", loadedOk);

                AddToTestResult(url, expectedReportName, reportType, execptedRowCount, actualRowCount, reportArgs, loadedOk, tableHasData, endTimeInSecs, evidenceFName, downloadedFileName);
            }

        }
        

    /// <summary
    /// gets the report count
    /// </summary>
    /// <returns></returns>
    private string GetReportCount()
        {
            string actualRowCount = "0";
            try
            {
                var browser = LetReportCompletelyLoad();
                var reportText = browser.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Text));
                for (int i = 0; i < reportText.Length; i++)
                {
                    if (reportText.ElementAt(i).Name.Contains("Record Count:"))
                    {
                        actualRowCount = reportText.ElementAt(i + 1).Name.Trim().Replace(",", "");
                        break;
                    }
                }
            }
            catch (Exception) { }
            return actualRowCount;
        }

        /// <summary>
        /// Wait for page to load
        /// </summary>
        /// <returns></returns>
        public static  FlaUI.Core.AutomationElements.AutomationElement WaitForMaskToClear(int waitInsec = 6)
        {
            Win32API.WaitForBrowserToLoad();
            var browser = Win32API.GetCurrentBrowser();
            int count = 1;
            var mask_one = browser.FindAllDescendants(x => x.ByText("Loading...")   );
            while (mask_one != null && mask_one.Count() >= 1 && count < waitInsec)
            {
                
                Thread.Sleep(1000);
                mask_one = browser.FindAllDescendants(x => x.ByText("Loading..."));
                count++;
            }
            var mask_two = browser.FindAllDescendants(x => x.ByText("Loading…"));
            while (mask_two != null && mask_two.Count() >= 1 && count < waitInsec)
            {

                Thread.Sleep(1000);
                mask_two = browser.FindAllDescendants(x => x.ByText("Loading…"));
                count++;
            }


            var interactionState = Win32API.GetCurrentBrowser().Patterns.Window.Pattern.WindowInteractionState.Value;
            while (interactionState != FlaUI.Core.Definitions.WindowInteractionState.ReadyForUserInteraction)
            {
                Thread.Sleep(400);
                interactionState = Win32API.GetCurrentBrowser().Patterns.Window.Pattern.WindowInteractionState.Value;
            }
            return browser;
        }

        public static FlaUI.Core.AutomationElements.AutomationElement LetReportCompletelyLoad()
        {
            Win32API.WaitForBrowserToLoad();
            var browser = Win32API.GetCurrentBrowser();
            var mask_one = browser.FindAllDescendants(x => x.ByText("Loading..."));
            while (mask_one != null && mask_one.Count() >= 1)
            {
                Thread.Sleep(1000);
                mask_one = browser.FindAllDescendants(x => x.ByText("Loading..."));
         
            }
            mask_one = browser.FindAllDescendants(x => x.ByText("Loading…"));
            while (mask_one != null && mask_one.Count() >= 1)
            {
                Thread.Sleep(1000);
                mask_one = browser.FindAllDescendants(x => x.ByText("Loading…"));

            }
            return browser;
        }

        /// <summary>
        /// flush
        /// </summary>
        public static void FlushReports()
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(reportData, "Regression_Run");
                var ws =  wb.Worksheet("Regression_Run");
                int index = 2;

                foreach (DataRow row in reportData.Rows)
                {
                    var dataInTableCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Is data in Table") + 1);
                    var viewReportsCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Can View Reports") +1);
                    var difInCountReportsCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Diff in Row Count") +1 );
                    var actualCountReportsCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Actual Row Count") + 1);
                    var reportType = ws.Row(index).Cell(reportData.Columns.IndexOf("Report Type") + 1);
                    var comments = ws.Row(index).Cell(reportData.Columns.IndexOf("Auto Generated Comments") + 1);

                    //color coding - view reports
                    if (viewReportsCell.Value.ToString().ToLower() ==  "true" )
                        viewReportsCell.Style.Fill.BackgroundColor = XLColor.LightSeaGreen;
                    else
                        viewReportsCell.Style.Fill.BackgroundColor = XLColor.Yellow;

                    
                    //color coding - differences in count reports
                    if (difInCountReportsCell.Value.ToString().ToLower() != "0" )
                    {
                        difInCountReportsCell.Style.Fill.BackgroundColor = XLColor.Yellow;
                    }


                    if (genericErrors.Length > 0)
                    {
                        comments.Value = genericErrors;
                        comments.Style.Fill.BackgroundColor = XLColor.Yellow;
                    }

                    //  picture evidence
                    var pictureCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Picture Evidence") + 1);
                    var pictureFName = pictureCell.Value.ToString();
                    if (pictureFName.Length >= 1 && File.Exists(pictureFName))
                    {
                        pictureCell.Value = "Picture Evidence " + index.ToString();
                        pictureCell.Hyperlink = new XLHyperlink(pictureFName);
                    }
                    else
                    {
                        pictureCell.Value = "Not found";
                        pictureCell.Style.Fill.BackgroundColor = XLColor.Red;
                    }

                    //  download evidence
                    var downloadCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Download Evidence") + 1);
                    var downloadFName = downloadCell.Value.ToString();
                    if (downloadFName.Length >= 1 && File.Exists(downloadFName))
                    {
                        var newFname = downloadFName.Replace(".xlsx", "_" + reportType.Value.ToString() + ".xlsx");
                        File.Move(downloadFName, newFname);
                        downloadFName = newFname;
                        downloadCell.Value = "Downloaded  XLSx file" + index.ToString();
                        downloadCell.Hyperlink = new XLHyperlink(newFname);
                    }
                    else
                    {
                        downloadCell.Value = "Not found";
                        downloadCell.Style.Fill.BackgroundColor = XLColor.Red;
                    }
                   
                    if (File.Exists(downloadFName))
                        dataInTableCell.Value = "true";
                    else
                        dataInTableCell.Value = "false";

                    //color coding - data  in table
                    if (dataInTableCell.Value.ToString().ToLower() != "true")
                        dataInTableCell.Style.Fill.BackgroundColor = XLColor.Yellow;
                    else
                        dataInTableCell.Style.Fill.BackgroundColor = XLColor.LightSeaGreen;

                    // link to report
                    var reportCell = ws.Row(index).Cell(reportData.Columns.IndexOf("Link To Report") + 1);
                    var url = reportCell.Value.ToString();
                    reportCell.Value = "Report Link " + index.ToString();
                    reportCell.Hyperlink = new XLHyperlink(url);

                    
                    index++;
                }

                ws.Columns().AdjustToContents();
                ws.SetAutoFilter(false);
                ws.Range("A2:O" + reportData.Rows.Count +1).Sort();
                wb.SaveAs(Page_Steps.ReportDir + @"\Report_Analysis.xlsx");
                wb.Dispose();
               
            }
        }
        /// <summary>
        /// Add to test report
        /// </summary>
        /// <param name="url"></param>
        /// <param name="expectedReportName"></param>
        /// <param name="execptedRowCount"></param>
        /// <param name="actualRowCount"></param>
        /// <param name="reportArgs"></param>
        /// <param name="loadedOk"></param>
        private void AddToTestResult(string url, string expectedReportName, string reportType,  string execptedRowCount, string actualRowCount, string[] reportArgs, bool loadedOk, bool tableHasData,   double elapseTimeInSecs, string evidenceFileName, string downloadedFileName)
        {



            reportData.Rows.Add(expectedReportName,
                                 reportType,
                                (url != "-"),
                                 url,
                                string.Join(",", reportArgs),
                                loadedOk,
                                Convert.ToInt32(execptedRowCount),
                                Convert.ToInt32(actualRowCount),
                                Convert.ToInt32(execptedRowCount) - Convert.ToInt32(actualRowCount),
                                tableHasData,
                                elapseTimeInSecs,
                               evidenceFileName,
                               downloadedFileName
                                );
        }



        /// <summary>
        /// Input data to the report
        /// </summary>
        /// <param name="browser"></param>
        /// <param name="paramInput"></param>
        /// <returns></returns>
        public bool InputParameters( string[] paramInput)
        {
            int inputCount = 0;
            int openButtonCount = 0;
            int editCount = 0;
            int checkBoxCount = 0;
            int embededCheckInputCount = 0;
            try
            {

                foreach (var args in paramInput)
                {
                    WaitForMaskToClear(1200);
                    var browser = GetBrowserAtFrame();

                    if (((args.Length == 10) && (DateTime.TryParseExact(args, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parseDate1)))
                           || ((args.Length == 8) && (DateTime.TryParseExact(args, "yyyymmdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parseDate2))))
                    {
                        var dates = GetBrowserAtFrame().FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Edit);
                        if (dates.Any() && dates.Count() > editCount)
                        {

                            var date = dates.ElementAt(editCount);
                            editCount++;

                            date.Click();

                            simulator.Keyboard.ModifiedKeyStroke(VirtualKeyCode.CONTROL,
                                new[] { VirtualKeyCode.VK_A });
                            simulator.Keyboard.KeyPress(VirtualKeyCode.BACK);
                            date.Click();
                            simulator.Keyboard.TextEntry(args);

                            inputCount++;

                        }
                        else
                        {
                            OpenAndSelect(args, ref openButtonCount, ref editCount, ref inputCount);
                        }
                        continue;
                    }
                    else if ((args.Length == 19) && (args.IndexOf("/") > 0))
                    {
                        IEnumerable<FlaUI.Core.AutomationElements.AutomationElement> sublistList = browser.FindAllDescendants(x => x.ByName("Open")).Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Button);
                        var foundElement = sublistList.Any() && sublistList.Count() > openButtonCount;

                        var open = sublistList.ElementAt(openButtonCount);
                        open.Click();
                        openButtonCount++;

                        for (int i = 0; i < 100; i++)
                            simulator.Keyboard.KeyPress(VirtualKeyCode.DOWN);
                        Thread.Sleep(300);

                        var options = Win32API.FindElementsName(args);
                        if (options.Any())
                        {
                            options[0].Click();
                            inputCount++;
                         
                        }
                    }
                    else if ((args.IndexOf("(") == 0) && (args.LastIndexOf(")") > 0))
                    {
                        WaitForMaskToClear(3);
                        IEnumerable<FlaUI.Core.AutomationElements.AutomationElement> sublistList = browser.FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Edit).Where(x => x.Patterns.Value.Pattern.IsReadOnly == true);
                        var foundElement = sublistList.Any() && sublistList.Count() > editCount;

                        var edit = sublistList.ElementAt(embededCheckInputCount);
                        edit.Click();

                        string NewArgs = args.Remove(0, 1);
                        NewArgs = NewArgs.Remove(NewArgs.Length -1, 1);
                        var options = Win32API.FindElementsByControlType( FlaUI.Core.Definitions.ControlType.CheckBox);
                        if (options.Any())
                        {
                            try
                            {
                                // unselect everything
                                var all = options.Where(x => x.Name.Equals("(Select All)" ) && x.IsOffscreen ==  false);
                                var state = all.ElementAt(0).Patterns.Toggle.Pattern.ToggleState.Value;
                                if (state.ToString() == "On")
                                {
                                    all.ElementAt(0).Click();
                                   
                                }

                                // select wanted
                                var optionWanted = options.Where(x => x.Name.Equals(NewArgs) && x.IsOffscreen == false);
                                 state = optionWanted.ElementAt(0).Patterns.Toggle.Pattern.ToggleState.Value;
                               
                                if (state.ToString() != "On")
                                    optionWanted.ElementAt(0).Click();

                                WaitForMaskToClear(3);
                                var control = browser.FindAllDescendants(x => x.ByControlType( FlaUI.Core.Definitions.ControlType.DataItem)).Where(x => x.IsOffscreen == false);
                                control.ElementAt(control.Count() - 1).Click();

                            }
                            catch(Exception E)
                            {
                                var A = E.Message;
                            }
                        }
                        inputCount++;
                        embededCheckInputCount++;

                    }
                    else if (args.Length >= 1 && args.ToLower() == "null")
                    {
            
                        var checkBoxes = browser.FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.CheckBox);
                        if (checkBoxes.Any() && checkBoxes.Count() > checkBoxCount)
                        {
                            checkBoxes = browser.FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.CheckBox);
                            var checkBox = checkBoxes.ElementAt(checkBoxCount);
                            var editItems = browser.FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Edit);

                            if (editItems.Any() && editItems.Count() > editCount)
                            {

                                var edit = editItems.ElementAt(editCount);
                                if (edit.IsEnabled)
                                {
                                    checkBox.Click();

                                }
                            }
                            inputCount++;
                            editCount++;
                            checkBoxCount++;
                        }
                        continue;
                    }
                    else if (args.Length >= 1 && args.ToLower() != "n/a")  // 
                    {

                        OpenAndSelect(args, ref openButtonCount, ref editCount, ref inputCount);
                    }
                    else if (args.ToLower() == "n/a") { inputCount++; continue; }

                    simulator.Keyboard.KeyPress(VirtualKeyCode.TAB);
                }
            }
            catch (Exception e)
            {
                genericErrors = e.Message.ToString(); inputCount = 0;

            }
            
            return  (inputCount == paramInput.Length) ||  (openButtonCount  + editCount + checkBoxCount + embededCheckInputCount == paramInput.Length) ;
        }


        int openButtonCount = 0;
        int editCount = 0;
        int checkBoxCount = 0;
        int embededCheckInputCount = 0;

        private void GetPotentialErrors()
        {

            try
            {
                var control = GetBrowserAtFrame().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.DataItem))
                      .Where(x => x.IsOffscreen == false);
                var pane = control.ElementAt(control.Count() - 1);
                var errors = pane.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.List));
                if (errors.Any())
                {
                    genericErrors = "";
                    foreach (var item in errors)
                    {
                        var text = item.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Text));
                        foreach (var innerText in text)
                        {
                            if (innerText.Name.ToString().ToLower().Contains("error") || innerText.Name.ToString().ToLower().Contains("fail"))
                            {
                                genericErrors += innerText.Name.ToString() + "\n";
                            }
                        }
                        break;

                    }
                }
            }
            catch (Exception e ) {
                int a = 5;
            }
        }


        /// <summary>
        /// open a control for editing
        /// </summary>
        /// <param name="args"></param>
        /// <param name="openButtonCount"></param>
        /// <param name="editCount"></param>
        /// <param name="inputCount"></param>
        private void OpenAndSelect( string args, ref int openButtonCount, ref int editCount, ref int inputCount)
        {
            bool foundElement = false;
            IEnumerable<FlaUI.Core.AutomationElements.AutomationElement> sublistList = null;
            WaitForMaskToClear(3);
           
            var browser = GetBrowserAtFrame();
            try
            {
                sublistList = browser.FindAllDescendants(x => x.ByName("Open")).Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Button);
                foundElement = sublistList.Any() && sublistList.Count() > openButtonCount;
            }
            catch (Exception) {  }

            if (foundElement)
            {
                try
                {
                 
                    Win32API.GetCurrentBrowser();
                    var open = sublistList.ElementAt(openButtonCount);
                    open.Click();
                    openButtonCount++;

                    for (int i = 0; i < 100; i++)
                        simulator.Keyboard.KeyPress(VirtualKeyCode.DOWN);
                    Thread.Sleep(300);
                    var options = Win32API.FindElementsByText("<Select a Value>");
                    if (options.Any())
                    {
                        var values = options.ElementAt(0).Parent.FindAllChildren();
                        foreach (var value in values)
                        {   
                            value.FocusNative();
                            if (value.Name == args)
                            {
                                value.Click();
                                inputCount++;
                                break;
                            }
                        }
                    }
                    else
                    {
                        var value = Win32API.FindElementsName(args).ElementAt(0);
                        value.Click();
                        inputCount++;
                    }
                }
                catch (Exception e) {
                    genericErrors = e.Message;
                    return ;
                }
            }
            else
            {
                var editItems = browser.FindAllDescendants().Where(x => x.ControlType == FlaUI.Core.Definitions.ControlType.Edit);

                if (editItems.Any() && editItems.Count() > editCount)
                {
                    var edit = editItems.ElementAt(editCount);
                    edit.Click();
                    editCount++;
                    inputCount++;
                    simulator.Keyboard.ModifiedKeyStroke(VirtualKeyCode.CONTROL,
                                new[] { VirtualKeyCode.VK_A });
                    simulator.Keyboard.TextEntry(args);
                    
                }
            }
        }
    
        
        /// <summary>
        /// download .xlsx file
        /// </summary>
        /// <param name="reportType"></param>
        /// <returns></returns>
        private string  DownloadToExcel(string reportType)
        {
            
            string downloadedFile = "";
       
            var download = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Button)).Where(x => x.Name.Contains("Export drop down menu"));
            if (!download.Any())
            {
                download = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Image)).Where(x => x.Name.Contains("Export"));
            }

            download.ElementAt(0).Click();
            WaitForMaskToClear(9000);
       
           var  excelLink = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Text)).Where(x => x.Name.Contains("Excel"));
            excelLink.ElementAt(0).Parent.Focus();
            excelLink.ElementAt(0).Parent.Click();
            try
            {
                var bar = GetNotificationBar();
                if (bar != null)
                {
                    var saveButton = GetNotificationBarSaveButton(bar);
                    if (saveButton != null)
                    {
                      
                        var foundSaveText = bar.FindAllDescendants().
                            Where(x => x.Name.Equals("Notification bar Text")).ElementAt(0).Patterns
                            .Value.Pattern.Value.ToString().Contains("Do you want to open or save");

                       var  splitButton = saveButton.FindAllDescendants();

                        while (!foundSaveText || !splitButton.Any())
                        {
                            Thread.Sleep(200);
                            foundSaveText = bar.FindAllDescendants().
                            Where(x => x.Name.Equals("Notification bar Text")).ElementAt(0).Patterns
                            .Value.Pattern.Value.ToString().Contains("Do you want to open or save");
                        }
                        Thread.Sleep(500);
                        splitButton = saveButton.FindAllDescendants();
                        splitButton.ElementAt(0).Click();

                        for (int i = 0; i < 10; i++)
                            simulator.Keyboard.KeyPress(VirtualKeyCode.RIGHT);

                        simulator.Keyboard.KeyPress(VirtualKeyCode.DOWN);
                        simulator.Keyboard.KeyPress(VirtualKeyCode.RETURN);
                        var saveAS = Win32API.FindElementsByControlType(FlaUI.Core.Definitions.ControlType.ComboBox).Where(x => x.Name.Equals("Save as type:"));

                        int count = 0;
                        while (!saveAS.Any()  && count < 50)
                        {
                            saveAS = Win32API.FindElementsByControlType(FlaUI.Core.Definitions.ControlType.ComboBox).Where(x => x.Name.Equals("Save as type:"));
                            count++;
                            Thread.Sleep(100);
                        }

                       var downloadedFileName = bar.FindAllDescendants().
                            Where(x => x.Name.Equals("Notification bar Text")).ElementAt(0).Patterns
                            .Value.Pattern.Value.ToString().Split(new string[] { "from" }, System.StringSplitOptions.RemoveEmptyEntries)[0]
                            .Split(new string[] { "save" }, System.StringSplitOptions.RemoveEmptyEntries)[1].Trim();

                        var fnameEntry =  downloadedFileName.Split(new string[] { "." }, System.StringSplitOptions.RemoveEmptyEntries);
                        downloadedFile = Page_Steps.ReportDir + reportType + "\\" + fnameEntry[0].Trim() + "." + fnameEntry[1].Trim();
                        
                        Keyboard.Type(downloadedFile);
                        Wait.UntilInputIsProcessed();

                        for (int i =0; i < 10; i++)
                         simulator.Keyboard.KeyPress(VirtualKeyCode.RIGHT);

                        simulator.Keyboard.KeyPress(VirtualKeyCode.RETURN);
                        simulator.Keyboard.KeyPress(VirtualKeyCode.RETURN);

                        var extension = fnameEntry[1].Trim();
                        if (extension.ToLower() == "xls")
                        {
                            count = 0;
                            while (!File.Exists(downloadedFile) && count < 50)
                            {
                                Thread.Sleep(100);
                                count++;
                            }
                            Workbook workbook = new Workbook();
                            
                            workbook.LoadFromFile(downloadedFile);
                            var newDownloadedFile = Page_Steps.ReportDir
                                               + reportType +
                                               "\\" + downloadedFileName.Split('.')[0] + ".xlsx";
                             workbook
                            .SaveToFile(newDownloadedFile, ExcelVersion.Version2016) ;
                           
                            workbook.Dispose();
                            workbook = null;
                            File.Delete(downloadedFile);
                            downloadedFile = newDownloadedFile;

                        }
                    }
                }
            }
            catch (Exception e) {
                genericErrors = e.Message;
            }
            return downloadedFile;
        }

        /// <summary>
        /// Notification bar
        /// </summary>
        /// <returns></returns>
        private FlaUI.Core.AutomationElements.AutomationElement GetNotificationBar()
        {
            FlaUI.Core.AutomationElements.AutomationElement [] notificationBar = null;
            try
            {
                do
                {
                    Thread.Sleep(1000);
                    notificationBar = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByAutomationId("IENotificationBar"));
                }
                while (!notificationBar.Any());
            }
            catch (Exception) {
                notificationBar = null;
                GetNotificationBar();
            }
            return notificationBar != null ? notificationBar.ElementAt(0) : null;
        }

        /// <summary>
        /// Notification bar save  button 
        /// </summary>
        /// <returns></returns>
        private FlaUI.Core.AutomationElements.AutomationElement GetNotificationBarSaveButton(FlaUI.Core.AutomationElements.AutomationElement bar)
        {
           IEnumerable< FlaUI.Core.AutomationElements.AutomationElement> notificationBarSaveButton = null;
            try
            {
                do
                {
                    Thread.Sleep(1000);
                    notificationBarSaveButton = bar.FindAllDescendants().Where(x => x.Name.ToLower().Equals("save"));
                }
                while (!notificationBarSaveButton.Any());
            }
            catch (Exception)
            {
                notificationBarSaveButton = null;
                GetNotificationBarSaveButton(bar);
            }
            return notificationBarSaveButton != null ? notificationBarSaveButton.ElementAt(0) : null;
        }


        /// <summary>
        ///  gets  browser at a frame
        /// </summary>
        /// <returns></returns>
        private FlaUI.Core.AutomationElements.AutomationElement GetBrowserAtFrame()
        {
      
            var firstPane = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Pane)).Where(x => x.Name.Contains("- Report Viewer"));
            var secondPane = Win32API.GetCurrentBrowser().FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Pane)).Where(x => x.Name.Contains("- Report Manager") && !x.Name.Contains("- Internet Explorer"));
            var pane = firstPane.Any() ? firstPane : secondPane;

            return (pane != null && pane.Count() >=1 )?  pane.ElementAt(0): null;

        }
        
        /// <summary>
        /// Wait for frame to appear
        /// </summary>
        private void WaitForFrameToAppear()
        {
            var Frame = GetBrowserAtFrame();
            bool looped = false;
            int count = 0;
            while (Frame == null && count < 240)
            {
                Thread.Sleep(1000);
                Frame = GetBrowserAtFrame();

                looped = true;
                count++;
            }

            if (looped)
            {
                Thread.Sleep(1500);
            }
        }

        public void ValidatePage()
        {

        }

    }
}

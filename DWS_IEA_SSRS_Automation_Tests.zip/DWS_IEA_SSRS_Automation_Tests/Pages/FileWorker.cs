﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
 using System.IO;
using ClosedXML.Excel;
using DataTableComparison;
using DWS_IEA_SSRS_Automation_Tests.Steps;

using Spire.Xls;


namespace DWS_IEA_SSRS_Automation_Tests.Pages
{
    public class FileWorker
    {
       
        private static Dictionary<string, List<DataTable>> comparisonDataTable = new Dictionary<string, List<DataTable>>();
        private static ManualResetEvent[] mainHandles;
        public static int Max_Concurrent_Worker_Threads = 10;
        public static List<BackgroundWorker>  workerInstance = new List<BackgroundWorker>();

        public void DoWorkToCompareFiles(string srcSSRSDirectory, string srcPBRSDirectory)
        {
            List<string> ssrsFiles   = new List<string>(); 
            List<string> pbrsFiles =   new List<string>(); 
            List<string> files = new List<string>();

            if (Directory.Exists(srcSSRSDirectory))
                ssrsFiles = Directory.GetFiles(srcSSRSDirectory).ToList();

            if (Directory.Exists(srcPBRSDirectory))
                pbrsFiles = Directory.GetFiles(srcPBRSDirectory).ToList();

            if (ssrsFiles.Any() && pbrsFiles.Any())
            {
                ssrsFiles.AddRange(pbrsFiles);
                files.AddRange(ssrsFiles);
            }
            else if (ssrsFiles.Any() && !pbrsFiles.Any())
            {
                files.AddRange(ssrsFiles);
            }
            else if (!ssrsFiles.Any() && pbrsFiles.Any())
            {
                files.AddRange(pbrsFiles);
            }
            RemoveUnnecessaryHeader(files);

            if (mainHandles != null)
            {
                if (mainHandles.Count() > 0)
                WaitHandle.WaitAll(mainHandles);

                if (files.Count() > 0)
                {
                    var compareDir = new DirectoryInfo(files[0]).Parent.Parent.FullName + @"\Compared";

                    if (!Directory.Exists(compareDir))
                        Directory.CreateDirectory(compareDir);

                    CompareDataListed(compareDir);

                    if (mainHandles != null)
                        WaitHandle.WaitAll(mainHandles);
                }

                updateAnalysisResults();
            }
        }

        /// <summary>
        ///  Remove unnecessary headers in xlsx
        ///  for data comparison
        /// </summary>
        /// <param name="files"></param>
        private void RemoveUnnecessaryHeader(List<string> files)
        {
           
             mainHandles = new ManualResetEvent[files.Count()];
            var batchHandles = new  List<ManualResetEvent>();
            int Max_Concurrent_Worker_Threads = 10;
            for (int i = 0; i < files.Count; i++)
            {
                try
                {
                    mainHandles[i] = new ManualResetEvent(false);

                    BackgroundWorker bgWorker = new BackgroundWorker(mainHandles[i], files[i]);
                    batchHandles.Add(mainHandles[i]);
                    //bgWorker.ConvertDownloadedFilesToDataTable();
                    ThreadPool.QueueUserWorkItem(x => bgWorker.ConvertDownloadedFilesToDataTable());
                }
                catch (Exception e) { var a = e.Message;  }
               
                if (i != 0 && i % Max_Concurrent_Worker_Threads == 0)
                {
                    lock (batchHandles)
                    {
                        WaitHandle.WaitAll(batchHandles.ToArray());
                        batchHandles.Clear();
                    }
                }
            }
          
        }



        private string FindAddressGivenReportName(IXLWorksheet workSheet, 
            string reportName, string columnNameOfAdress)
        {
        
            string address = "";
            reportName = reportName.Split(new string[] { "_Full_Compare.xlsx" }, System.StringSplitOptions.RemoveEmptyEntries)[0];
            var rowCollection = workSheet.Rows();
            int reportIndex = 1;

            var columnCell = workSheet.RangeUsed().FindColumn(c => c.FirstCell().Value.ToString() == columnNameOfAdress);
            for (int i = 1; i < rowCollection.Count(); i++)
            {
                
                var row = rowCollection.ElementAt(i);
                if ( row.Cell(reportIndex).Value.ToString() == reportName )
                {

                    address = columnCell.Cell(i+1).Address.ToString();
                    if (i + 1 < rowCollection.Count())
                    {
                        var nextRow = rowCollection.ElementAt(i + 1);
                        if (nextRow.Cell(reportIndex).Value.ToString() == reportName)
                        {
                            address = address + ":" + columnCell.Cell(i + 2).Address.ToString();
                        }
                    }
                    break;
                }
            }

            return address;
        }
        /// <summary>
        /// Compares files and 
        /// </summary>
        private  void CompareDataListed(string comparedirectory)
        {

            mainHandles = null;
            mainHandles = new ManualResetEvent[comparisonDataTable.Count()];
            var batchHandles = new List<ManualResetEvent>();
            workerInstance.Clear();
            int Max_Concurrent_Worker_Threads = 10;

            for (int i = 0; i < comparisonDataTable.Count; i++)
            {
                mainHandles[i] = new ManualResetEvent(false);

                List<DataTable>   dtList = comparisonDataTable.Values.ElementAt(i);
                var fileID  = comparisonDataTable.Keys.ElementAt(i);
                BackgroundWorker bgWorker = new BackgroundWorker(mainHandles[i], dtList, fileID, comparedirectory);
                workerInstance.Add(bgWorker);

                batchHandles.Add(mainHandles[i]);
                // bgWorker.GenerateComparisonReport();
                ThreadPool.QueueUserWorkItem(x => bgWorker.GenerateComparisonReport());

                if (i != 0 && i % Max_Concurrent_Worker_Threads == 0)
                {
                    lock (batchHandles)
                    {
                        WaitHandle.WaitAll(batchHandles.ToArray());
                        batchHandles.Clear();
                    }
                }

                if (comparisonDataTable.Count == 0)
                    mainHandles = null;
            }
        }


        /// <summary>
        /// Update spreadsheets
        /// </summary>
        private void updateAnalysisResults()
        {
            XLWorkbook analysisWB = new XLWorkbook(Page_Steps.ReportDir + @"\\Report_Analysis.xlsx");
            IXLWorksheet workSheet = analysisWB.Worksheet(1);

            foreach (var bgItem in workerInstance)
            {
                try
                {
                    var matchAddress = FindAddressGivenReportName(workSheet, bgItem.ReportName, "Data Match");
                    var CommentsAddress = FindAddressGivenReportName(workSheet, bgItem.ReportName, "Auto Generated Comments");

                    workSheet.Range(matchAddress).Merge();
                    workSheet.Range(CommentsAddress).Merge();

                    workSheet.Cell(matchAddress.Split(':')[0]).Value = bgItem.compareResult.ToString();

                    var fullFileName = bgItem.outputDirectory + @"\" + bgItem.analysisFName;

                    if (File.Exists(fullFileName))
                        workSheet.Cell(matchAddress.Split(':')[0]).Hyperlink = new XLHyperlink(fullFileName);


                    

                    if (bgItem.compareResult && bgItem.rowsAnalyzed > 0)
                        workSheet.Cell(matchAddress.Split(':')[0]).Style.Fill.BackgroundColor = XLColor.LightSeaGreen;

                    if (bgItem.compareMessage.ToLower().IndexOf("match"  ) < 0)
                    {
                        workSheet.Cell(matchAddress.Split(':')[0]).Style.Fill.BackgroundColor = XLColor.Yellow;
                    }

                    else if (bgItem.compareMessage.IndexOf("Failed To Compare:") >= 0)
                        workSheet.Cell(matchAddress.Split(':')[0]).Style.Fill.BackgroundColor = XLColor.Yellow;

                    else if (!bgItem.compareResult && bgItem.compareMessage.IndexOf("Failed To Compare:") < 0)
                        workSheet.Cell(matchAddress.Split(':')[0]).Style.Fill.BackgroundColor = XLColor.Red;

                    workSheet.Cell(CommentsAddress.Split(':')[0]).Value = bgItem.compareMessage;
                }
                catch(Exception)
                {

                }
            }

            
            workSheet.Columns().AdjustToContents();
            foreach (var item in workSheet.Columns())
            {
                item.Style.Font.SetBold();
            }
            workSheet.SetAutoFilter(false);

            analysisWB.Save();
            analysisWB.Dispose();

             
        }

    public class BackgroundWorker
        {
            private ManualResetEvent doneEvent;
            private string fileName;
            private string fullFilePath;
            public DataTable dt;
            private XLWorkbook workBook;
            private DataTableComparer dtComparer;
            private List<DataTable> listOfDTCompared;
            private string primaryKey = "Dynamic_PK";

            private string columnMarker = "";
            public string analysisFName = "";
            public string outputDirectory = "";
            public string compareMessage = "";
            public bool compareResult = false;
            public string ReportName = "";
            public string errorFName = "";
            public string matchFName = "";
            public int rowsAnalyzed = 0;


            /// <summary>
            /// to compare 2 or more files
            /// </summary>
            /// <param name="inEvent"></param>
            /// <param name="inDTList"></param>
            /// <param name="inOutDir"></param>
            public BackgroundWorker(ManualResetEvent inEvent, List<DataTable> inDTList, string fileID, string inOutDir)
            {
                doneEvent = inEvent;
                listOfDTCompared = inDTList;
                dtComparer = new DataTableComparer();
                outputDirectory = inOutDir;
                
                ReportName = ((fileID.Replace("_.xlsx", "")) );
                compareMessage = "";
                compareResult = false;

            }

            /// <summary>
            /// to remove un-used row and set primary key
            /// </summary>
            /// <param name="inEvent"></param>
            /// <param name="inFullFilePath"></param>
            public BackgroundWorker(ManualResetEvent inEvent, string inFullFilePath)
            {
                FileInfo fi = new FileInfo(inFullFilePath);
                DirectoryInfo di = new DirectoryInfo(inFullFilePath);
                doneEvent = inEvent;
                fullFilePath = inFullFilePath;
                fileName = fi.Name;
                columnMarker = Page_Steps.reportPK[fileName.Replace(fi.Extension, "")];
                dt = new DataTable();
                dt.TableName = fileName.Replace(fi.Extension,  "_")  + di.Parent.Name;
                ReportName = ((fi.Name.Replace(fi.Extension, "")).Replace("_PBRS", "")).Replace("_SSRS", "");



                workBook = new XLWorkbook();
                workBook.FullCalculationOnLoad = false;

                compareMessage = "";
                compareResult = false;
                fi = null;
                di = null;
            }




            /// <summary>
            ///  Load a file based on a filter on sheets To load
            /// </summary>
            /// <returns></returns>
            public void LoadDT()
            {

                using (Workbook workbook = new Workbook())
                {
                    try
                    {
                        List<int> colIndex = new List<int>();

                        var name = fileName.Replace(".xlsx", "");
                        workbook.LoadFromFile(fullFilePath.Replace(name, name + "_original"), ExcelVersion.Version2016);

                        bool foundColOfInterest = false;

                        dt.Clear();
                        if (!dt.Columns.Contains(primaryKey))
                        {
                            dt.Columns.Add(primaryKey);
                            dt.PrimaryKey = new DataColumn[] { dt.Columns[primaryKey] };
                        }

                        foreach (var item in workbook.Worksheets)
                        {
                            if (item.Name != "Evaluation Warning")
                            {
                                int index = 1;
                               // item.Range.UnMerge();
                                colIndex.Clear();
                                foreach (var row in item.Rows)
                                {
                                    if (!foundColOfInterest)
                                    {
                                        if (row.IsBlank || (!row.CellList.Where(x => x.Value.ToString().ToLower().Equals(columnMarker.ToLower())).Any()))
                                            continue;

                                        // add columns
                                        foreach (var cell in row.CellList)
                                        {
                                            if (!string.IsNullOrEmpty(cell.Value.ToString()))
                                            {

                                                colIndex.Add(index);
                                                dt.Columns.Add(cell.Value.ToString(), typeof(String));
                                            }
                                            index++;
                                        }
                                        foundColOfInterest = true;
                                        continue;
                                    }

                                    if (!row.CellList.Any())
                                    {
                                        break;
                                    }

                                    // add rows
                                    index = 1;
                                    DataRow toInsert = dt.NewRow();
                                    bool hasData = false;
                                    foreach (var counter in colIndex)
                                    {
                                        var text = row.CellList[counter - 1].Value;
                                        toInsert[index++] = text != null ? text.Replace("\t", "") : "";
                                        
                                        if (text != null && text.Length >= 1)
                                            hasData = true;
                                    }
                                    if (!hasData)
                                    {
                                        toInsert.Delete();
                                        continue;
                                    }
                                    toInsert[0] = string.Join("_", toInsert.ItemArray.ToArray());
                                    dt.Rows.Add(toInsert);
                                }
                            }
                            
                        }
                    }
                    catch (Exception) { }
                    finally {
                        workbook.Dispose(); }
                }
                   
            }


            /// <summary>
            /// Convert files to datatable for later comparison
            /// 1. Removes unnecessary headers
            /// 2. Adds default Pimary Key
            /// </summary>
            public void ConvertDownloadedFilesToDataTable()
            {

                try
                {
                    PurgeOriginalSheet();  
                    lock (dt)
                    {
                        LoadDT();

                        try
                        {
                            if (dt.Rows.Count == 0)
                            {
                                compareMessage = "No Reconcilliation because the reports are blank";
                                DataRow toInsert = dt.NewRow();
                                for (int i = 0; i < toInsert.ItemArray.Length; i++)
                                {
                                    toInsert[i] = "";
                                }
                                dt.Rows.Add(toInsert);
                            }
                            var tableName = dt.TableName.Length > 31 ? dt.TableName.Substring(0, 31) : dt.TableName;
                            workBook.AddWorksheet(dt, tableName);
                            workBook.SaveAs(fullFilePath, false, false);
                        }
                        catch(Exception e) {
                            var a = e.Message;
                        }

                    }
                    lock (comparisonDataTable)
                    {
                        var newFName = fileName.Replace("PBRS", "").Replace("SSRS", "");
                        if (!comparisonDataTable.ContainsKey(newFName))
                        {
                            List<DataTable> lstDataTable = new List<DataTable>();
                            lstDataTable.Add(dt);
                           
                            comparisonDataTable.Add(newFName, lstDataTable);
                            
                        }
                        else
                        {
                            List<DataTable> lstDataTable = comparisonDataTable[newFName];
                            lstDataTable.Add(dt);
                            
                           comparisonDataTable[newFName] = lstDataTable;
                            
                        }
                    }
                }
                catch (Exception e)
                {
                    compareMessage = e.Message;
                    compareResult = false;
                }
                finally {
                 
                    doneEvent.Set(); }
            }


        /// <summary>
        /// 
        /// </summary>
        public void PurgeOriginalSheet()
        {
            if (File.Exists(fullFilePath))
            {
                 var name = fileName.Replace(".xlsx", "");
                File.Move(fullFilePath, fullFilePath.Replace(name, name + "_original"));
                var changes = new XLWorkbook(fullFilePath.Replace(name, name + "_original"));

                    IXLWorksheet unwanted = null;
                    foreach (var item in changes.Worksheets)
                    {
                        if (item.Name == "Evaluation Warning")
                        {
                            unwanted = item;
                            break;
                        }
                    }

                    if (unwanted != null)
                    {
                        try
                        {
                            unwanted.Delete();
                            changes.Save(false, false);
                            changes.Dispose();
                        }
                        catch (Exception) { }
               
                    }

                   
            }
        }

            /// <summary>
            /// Generate .csv Reports on data comparison
            /// This includes 
            /// 1. Working Spreadsheet
            /// 2. Columns with errors 
            /// 3. Summary of Reports run

            public void GenerateComparisonReport()
            {
                try
                {
                    lock (dtComparer)
                    {
                        lock (listOfDTCompared)
                        {
                            dtComparer.DataTables.Clear();

                            foreach (DataTable item in listOfDTCompared)
                                dtComparer.AddTable(item);

                            analysisFName = listOfDTCompared[0].TableName.Split('_')[0] + "_Full_Compare.xlsx"; 
                            if (listOfDTCompared.Count >= 2)
                            {
                                

                                dtComparer.Config.ColumnNamesCaseSensitive = false;
                                dtComparer.Config.DataFieldValuesCaseSensitive = false;
                                dtComparer.Config.WordSeperator = "\t";
                                var comparedObj = dtComparer.Compare();
                                DataTable dtResults = comparedObj.ResultsDataTable;

                                DataTable dtSimilair=  ParseSimilarRecords(dtResults);
                                DataTable dtDifference = ParseDifferencesRecords(dtResults);
                              
                                compareResult = comparedObj.AllTablesContainTheSamePrimaryKeysRows() && dtDifference.Rows.Count ==0;

                                // generate error report
                                var Records = new XLWorkbook();
                                
                                Records.AddWorksheet(dtSimilair);
                                Records.AddWorksheet(dtDifference);
                                Records.AddWorksheet(dtResults, "Fully_Compared_Recordset");
                                for (int i =1; i <= Records.Worksheets.Count; i++) 
                                    Records.Worksheet(i).ExpandColumns();
                                
                                Records.SaveAs(outputDirectory + @"\" + analysisFName, false, false);
                                Records.Dispose();


                                rowsAnalyzed = dtResults.Rows.Count;
                                
                                if (!compareResult)
                                    compareMessage = "Failed To Match:" + "There are " + dtDifference.Columns.Count.ToString()  + "questionable columns ";
                                else if (rowsAnalyzed <= 0)
                                    compareMessage = "No Records: Rows analyed " + rowsAnalyzed;
                                else if (dtSimilair.Rows.Count == 0 && dtDifference.Rows.Count == 0 )
                                    compareMessage = "No Reconciliation because the reports are blank" ;
                                else 
                                    compareMessage = "Matched Records: Rows analyed " + rowsAnalyzed;
                            }
                            else
                            { 
                                compareMessage = "Failed To Compare: To or more Data Tables required";
                            }
                        }
                    }
                }
                catch (Exception e) { compareResult = false;
                    compareMessage = "Failed To Compare: " + e.Message;
                }
                finally { doneEvent.Set(); }

            }

            /// <summary>
            /// get similar records
            /// </summary>
            /// <param name="results"></param>
            /// <returns></returns>
            private DataTable ParseSimilarRecords(DataTable results)
            {
                List<int> dataIndex = new List<int>();

                DataTable ResultDataTable = new DataTable("Similar_Records");
                int colIndex = 0;
                foreach (DataColumn cols in results.Columns)
                {
                    if ((!cols.ColumnName.Contains("Exists_")  && !cols.ColumnName.Contains("Status")))
                    {
                        ResultDataTable.Columns.Add(cols.ColumnName);
                        dataIndex.Add(colIndex);
                    }
                    colIndex++;
                }

                int rIndex = 0;
                bool toAddRow = false;
                foreach (DataRow row in results.Rows)
                {
                    colIndex = 0;
                    toAddRow = false;
                    DataRow toInsert = ResultDataTable.NewRow();
                    
                    var arrRow = row.ItemArray.ToList();
                    if (arrRow.Where(p => p.ToString().Equals("Out of Sync")).Any()

                            )
                    {
                        toInsert.Delete();
                        continue;
                    }
                    int index = 0;
                    foreach (int cIndex in dataIndex)
                    {

                        var text = results.Rows[rIndex][cIndex].ToString();
                        toInsert[index++] = text;
                        if (text != null && text.Length >= 1)
                            toAddRow = true;
                    }

                    if (toAddRow)
                    {
                        ResultDataTable.Rows.Add(toInsert);
                    }
                    else
                    {
                        toInsert.Delete();
                    }
                    rIndex++;
                }

                return ResultDataTable;
            }


            private DataTable ParseDifferencesRecords(DataTable results)
            {
                List<int> dataIndex = new List<int>();

                DataTable ResultDataTable = new DataTable("Differences_In_Records");
                int colIndex = 0;
                foreach (DataColumn cols in results.Columns)
                {
                    if ((!cols.ColumnName.Contains("Exists_") && !cols.ColumnName.Contains("Status")))
                    {
                        ResultDataTable.Columns.Add(cols.ColumnName);
                        dataIndex.Add(colIndex);
                    }
                    colIndex++;
                }

                int rIndex = 0;
                bool toAddRow = false;
                foreach (DataRow row in results.Rows)
                {
                    colIndex = 0;
                    toAddRow = false;
                    DataRow toInsert = ResultDataTable.NewRow();

                    var arrRow = row.ItemArray.ToList();
                    if (!arrRow.Where(p => p.ToString().Equals("Out of Sync")).Any()

                            )
                    {
                        toInsert.Delete();
                        continue;
                    }
                    int index = 0;
                    foreach (int cIndex in dataIndex)
                    {

                        var text = results.Rows[rIndex][cIndex].ToString();
                        toInsert[index++] = text;
                        if (text != null && text.Length >= 1)
                            toAddRow = true;
                    }

                    if (toAddRow)
                    {
                        ResultDataTable.Rows.Add(toInsert);
                    }
                    else
                    {
                        toInsert.Delete();
                    }
                    rIndex++;
                }

                return ResultDataTable;
            }


            /// <summary>
            /// Get datatable difference
            /// </summary>
            /// <param name="FirstDataTable"></param>
            /// <param name="SecondDataTable"></param>
            /// <returns></returns>
            public DataTable GetDifferentRecords(DataTable FirstDataTable, DataTable SecondDataTable)
            {
               
                DataTable ResultDataTable = new DataTable("Differences_In_Records");
                using (DataSet ds = new DataSet())
                {
                    try
                    {

                        ds.Tables.AddRange(new DataTable[] { FirstDataTable.Copy(), SecondDataTable.Copy() });

                        //Get Columns for DataRelation  
                        DataColumn[] firstColumns = new DataColumn[ds.Tables[0].Columns.Count];

                        for (int i = 0; i < firstColumns.Length; i++)
                            firstColumns[i] = ds.Tables[0].Columns[i];


                        DataColumn[] secondColumns = new DataColumn[ds.Tables[1].Columns.Count];
                        for (int i = 0; i < secondColumns.Length; i++)
                            secondColumns[i] = ds.Tables[1].Columns[i];

                        //Create DataRelation  
                        DataRelation r1 = new DataRelation(string.Empty, firstColumns, secondColumns, false);
                        ds.Relations.Add(r1);

                        DataRelation r2 = new DataRelation(string.Empty, secondColumns, firstColumns, false);
                        ds.Relations.Add(r2);

                        //Create columns for return table  
                        for (int i = 0; i < FirstDataTable.Columns.Count; i++)
                            ResultDataTable.Columns.Add(FirstDataTable.Columns[i].ColumnName, FirstDataTable.Columns[i].DataType);


                        //If FirstDataTable Row not in SecondDataTable, Add to ResultDataTable.  
                        ResultDataTable.BeginLoadData();
                        foreach (DataRow parentrow in ds.Tables[0].Rows)
                        {
                            DataRow[] childrows = parentrow.GetChildRows(r1);

                            if (childrows == null || childrows.Length == 0)

                                ResultDataTable.LoadDataRow(parentrow.ItemArray, true);
                        }

                        //If SecondDataTable Row not in FirstDataTable, Add to ResultDataTable.  
                        foreach (DataRow parentrow in ds.Tables[1].Rows)
                        {
                            DataRow[] childrows = parentrow.GetChildRows(r2);

                            if (childrows == null || childrows.Length == 0)

                                ResultDataTable.LoadDataRow(parentrow.ItemArray, true);

                        }
                        ResultDataTable.EndLoadData();
                    }
                    catch (Exception)
                    {
                        ResultDataTable = null;
                    }
                }

                return ResultDataTable;

            }



            /// <summary>
            /// Get datatable difference
            /// </summary>
            /// <param name="FirstDataTable"></param>
            /// <param name="SecondDataTable"></param>
            /// <returns></returns>
            public DataTable GetSimilarRecords(DataTable FirstDataTable, DataTable SecondDataTable)
            {

                DataTable ResultDataTable = new DataTable("Similar_Records");
                using (DataSet ds = new DataSet())
                {
                    try
                    {
                        ds.Tables.AddRange(new DataTable[] { FirstDataTable.Copy(), SecondDataTable.Copy() });

                        //Get Columns for DataRelation  
                        DataColumn[] firstColumns = new DataColumn[ds.Tables[0].Columns.Count];

                        for (int i = 0; i < firstColumns.Length; i++)
                            firstColumns[i] = ds.Tables[0].Columns[i];


                        DataColumn[] secondColumns = new DataColumn[ds.Tables[1].Columns.Count];
                        for (int i = 0; i < secondColumns.Length; i++)
                            secondColumns[i] = ds.Tables[1].Columns[i];

                        //Create DataRelation  
                        DataRelation r1 = new DataRelation(string.Empty, firstColumns, secondColumns, false);
                        ds.Relations.Add(r1);

                        DataRelation r2 = new DataRelation(string.Empty, secondColumns, firstColumns, false);
                        ds.Relations.Add(r2);

                        //Create columns for return table  
                        for (int i = 0; i < FirstDataTable.Columns.Count; i++)
                            ResultDataTable.Columns.Add(FirstDataTable.Columns[i].ColumnName, FirstDataTable.Columns[i].DataType);


                        //find similarities  
                        ResultDataTable.BeginLoadData();
                        foreach (DataRow parentrow in ds.Tables[0].Rows)
                        {
                            DataRow[] childrows = parentrow.GetChildRows(r1);

                            if (childrows != null && childrows.Length > 0)

                                ResultDataTable.LoadDataRow(parentrow.ItemArray, true);
                        }


                        foreach (DataRow parentrow in ds.Tables[1].Rows)
                        {
                            DataRow[] childrows = parentrow.GetChildRows(r2);

                            if (childrows != null || childrows.Length > 0)

                                ResultDataTable.LoadDataRow(parentrow.ItemArray, true);

                        }
                        ResultDataTable.EndLoadData();
                    }catch(Exception)
                    {
                        ResultDataTable = null;
                    }
                }
                return ResultDataTable;
            }



        }
    }
}
